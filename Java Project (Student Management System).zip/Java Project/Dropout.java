/*The Dropout class is also a sub class of the parent class,Student.
 * It has five Attributes.
 */

public class Dropout extends Student {
    private int remainingModules;//Private Instance variable
    private int numOfMonthsAttended;
    private String dropoutDate;
    private int remainingAmount;
    private boolean hasPaid;

    //Constructor
    public Dropout(String dateOfBirth, String studentName,int courseDuration, int tuitionFee, int enrollmentId, 
   String courseName, String dateOfEnrollment, int remainingModules,int numOfMonthsAttended, String dropoutDate)
                
    {
        //calling parent class[Student Class] constructor
        super(dateOfBirth, studentName, courseDuration, tuitionFee);
        super.setEnrollmentID(enrollmentId);
        super.setCourseName(courseName);
        super.setDateOfEnrollment(dateOfEnrollment);

        //Assigning the value
        this.remainingModules = remainingModules;
        this.numOfMonthsAttended=numOfMonthsAttended;
        this.dropoutDate = dropoutDate;
        this.remainingAmount = 0;  //Assigning default value of remainingAmount to 0
        this.hasPaid = false;  //Assigning default value of hasPaid to false
    }

    //Accessor/getter
    public int getNumOfRemainingModules() {
        return remainingModules;
    }

    public int getNumOfMonthsAttended() {
        return numOfMonthsAttended;
    }

    public String getDateOfDropout() {
        return dropoutDate;
    }

    public int getRemainingAmount() {
        return remainingAmount;
    }

    public boolean getHasPaid() {
        return hasPaid;
    }

    // Method[billsPayable] for calculating pending tuition fees.
    public boolean billsPayable() {
        remainingAmount = (getCourseDuration()/30- getNumOfMonthsAttended()) * getTuitionFee();
       // System.out.println("Pending Tuition fees: " + remainingAmount);
        this.hasPaid = true;
        return hasPaid;
    }

    //Method to remove data from the object student
    public void removeStudent() {
        if (hasPaid) {
            setDateOfBirth("");
            setCourseName("");
            setStudentName("");
            setDateOfEnrollment("");
            setCourseDuration(0);
            setTuitionFee(0);
            setEnrollmentID(0);
            remainingModules = 0;
            numOfMonthsAttended = 0;
            remainingAmount = 0;
            dropoutDate = "";
        } else {
           // System.out.println("All bills not cleared");
        }
    }

    //Method to display details of Parent class and Dropout class
    public void display() {
        super.display();
        System.out.println("The number of remaining modules: "+ getNumOfRemainingModules());
        System.out.println("The numbers of month attended: "+ getNumOfMonthsAttended());
        System.out.println("The date of Dropout: "+ getDateOfDropout());
        System.out.println("The remaining amount: "+ getRemainingAmount());
    }


}