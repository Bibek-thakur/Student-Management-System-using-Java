
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class StudentGUI implements ActionListener {
    private JFrame frame;
    private ArrayList<Student> studentList = new ArrayList<>();//ArrayList
    private JPanel panel;

    private JLabel Head;
    private JButton dropoutButton;

    private JLabel studentName;
    private JLabel enrollmentId;
    private JLabel courseName;
    private JLabel courseDuration;
    private JLabel tuitionFee;
    private JLabel numberOfModules;
    private JLabel numberOfCreditHours;
    private JLabel DaysPresent;
    private JLabel dateOfBirth;
    private JLabel dateOfEnrollment;

    private JTextField studentNameTextField;
    private JTextField enrollmentIdTextField;
    private JTextField courseDurationTextField;
    private JTextField tuitionFeeTextField;
    private JTextField numberOfModulesTextField;
    private JTextField numberOfCreditHoursTextField;
    private JTextField DaysPresentTextField;

    private JComboBox courseNameComboBox,courseNameComboBox2;
    private JComboBox dayComboBox,monthComboBox,yearComboBox;// combobox 
    private JComboBox dayComboBox2,monthComboBox2,yearComboBox2;//combobox
    private JButton addRegularButton,presentPercentageButton,grantCertificateButton,displayButton,clearButton;//Buttons
    private JLabel enrollmentId2;
    private JTextField enrollmentIdText2;
    private JLabel DaysPresent2;
    private JTextField DaysPresentText2;
    private JLabel enrollmentId3;
    private JTextField enrollmentIdText3;
    private JLabel courseName2;
    private JLabel dateOfEnrollment2;
    private JComboBox dayComboBox3, monthComboBox3,yearComboBox3;

    //for Dorpout class
    private JPanel panel2;
    private JLabel Head2;
    private JButton regularButton;
    private JLabel studentName2;
    private JTextField studentNameText2;
    private JLabel enrollmentId_DropOut,enrollmentId_DropOut2,enrollmentId_DropOut3;
    private JTextField enrollmentIdText_DropOut,enrollmentIdText_DropOut2,enrollmentIdText_DropOut3;
    private JLabel courseName_Dropout;
    private JComboBox courseNameComboBox_Dropout;
    private JLabel courseDuration_Dropout;
    private JTextField courseDurationText_Dropout;
    private JLabel tuitionFee_Dropout;
    private JTextField tuitionFeeText_Dropout;
    private JLabel Dob_Dropout;
    private JComboBox dayComboBox_Dropout,monthComboBox_Dropout,yearComboBox_Dropout;
    private JLabel monthsAttended;
    private JTextField monthsAttendedText;
    private JLabel remainingModules;
    private JTextField remainingModulesText;
    private JLabel enrollmentDate_Dropout;
    private JComboBox dayComboBox_Dropout2,monthComboBox_Dropout2,yearComboBox_Dropout2;
    private JLabel dropoutDate;
    private JComboBox dayComboBox_Dropout3,monthComboBox_Dropout3,yearComboBox_Dropout3;
    private JButton addDropoutButton,removeStudentButton,billsPaidButton,clearDropout,displayDropout;
    //Constructor for Objects
    public StudentGUI() {
        frame = new JFrame("Student Management System");
        //for Regular
        panel = new JPanel();
        panel.setSize(760, 700);
        panel.setBackground(new Color(150,210,240)); // [RGB] Setting background color for panel
        panel.setLayout(null);

        Head = new JLabel("Student Management System");
        Head.setBounds(250, 30, 300, 100);//x,y width, length.
        Head.setFont(new Font("SansSerif", Font.BOLD, 20));
        panel.add(Head); 

        dropoutButton = new JButton("Go To DroupOut>>>");
        dropoutButton.setBounds(30,50,170,50);
        dropoutButton.setBackground(new Color(80,85,85));//RGB 
        dropoutButton.setForeground(Color.WHITE);
        dropoutButton.setFont(new Font("Fantasy",Font.BOLD,12));
        panel.add(dropoutButton);
        dropoutButton.addActionListener(this);// making button working!

        studentName= new JLabel("Student Name");
        studentName.setBounds(30,150,100,40);
        studentNameTextField = new JTextField();
        studentNameTextField.setBounds(150,150,150,40);
        panel.add(studentName); 
        panel.add(studentNameTextField); 

        enrollmentId = new JLabel("Enrollment ID");
        enrollmentId.setBounds(30,200,100,40);
        enrollmentIdTextField = new JTextField();
        enrollmentIdTextField.setBounds(150,200,150,40);
        panel.add(enrollmentId); 
        panel.add(enrollmentIdTextField);

        courseName = new JLabel("Course Name");
        courseName.setBounds(30,250,100,40);
        String[] courses = {"Java","Python","C++","C#","Java Script","php"};
        courseNameComboBox = new JComboBox<>(courses);
        courseNameComboBox.setBounds(150,250,150,40);
        panel.add(courseName); 
        panel.add(courseNameComboBox);

        courseDuration = new JLabel("Course Duration");
        courseDuration.setBounds(30,300,100,40);
        courseDurationTextField = new JTextField();
        courseDurationTextField.setBounds(150,300,150,40);
        panel.add(courseDuration); 
        panel.add(courseDurationTextField);

        tuitionFee = new JLabel("Tuition Fee");
        tuitionFee.setBounds(30,350,100,40);
        tuitionFeeTextField = new JTextField();
        tuitionFeeTextField.setBounds(150,350,150,40);
        panel.add(tuitionFee); 
        panel.add(tuitionFeeTextField);

        DaysPresent = new JLabel("Days present");
        DaysPresent.setBounds(340,150,100,50);
        DaysPresentTextField = new JTextField();
        DaysPresentTextField.setBounds(500,150,150,40);
        panel.add(DaysPresent); 
        panel.add(DaysPresentTextField);

        numberOfModules = new JLabel("Number Of Modules");
        numberOfModules.setBounds(340,200,150,50);
        numberOfModulesTextField = new JTextField();
        numberOfModulesTextField.setBounds(500,200,150,40);
        panel.add(numberOfModules);
        panel.add(numberOfModulesTextField);

        numberOfCreditHours = new JLabel("Number Of Credit Hours");
        numberOfCreditHours.setBounds(340,250,150,50);
        numberOfCreditHoursTextField= new JTextField();
        numberOfCreditHoursTextField.setBounds(500,250,150,40);
        panel.add(numberOfCreditHours);
        panel.add(numberOfCreditHoursTextField);
        //Combo box of Date of enrollment.
        dateOfEnrollment = new JLabel("Enrollment Date");
        dateOfEnrollment.setBounds(340,300,95,50);
        panel.add(dateOfEnrollment);
        dayComboBox = new JComboBox();
        for(int i=1; i<=31; i++)
        {
            dayComboBox.addItem(i);
        }
        dayComboBox.setBounds(455,315,40,20);
        panel.add(dayComboBox);

        String[] months={"January","February","March","April","May","June","July","August","September","October","November","December"};
        monthComboBox =new JComboBox<>(months);
        monthComboBox.setBounds(505,315,85,20);
        panel.add(monthComboBox);
        yearComboBox = new JComboBox();
        for(int i=1999; i<=2023; i++)
        {
            yearComboBox.addItem(i);
        }
        yearComboBox.setBounds(595,315,70,20);
        panel.add(yearComboBox);

        //Combo box of Date of Birth.
        dateOfBirth = new JLabel("Date Of Birth");
        dateOfBirth.setBounds(340,350,95,50);
        panel.add(dateOfBirth);
        dayComboBox2= new JComboBox();
        for(int i=1; i<=31; i++)
        {
            dayComboBox2.addItem(i);
        }
        dayComboBox2.setBounds(455,365,40,20);
        panel.add(dayComboBox2);

        String[] months2={"January","February","March","April","May","June","July","August","September","October","November","December"};
        monthComboBox2 =new JComboBox<>(months);
        monthComboBox2.setBounds(505,365,85,20);
        panel.add(monthComboBox2);

        yearComboBox2 = new JComboBox();
        for(int i=1990; i<=2010; i++)
        {
            yearComboBox2.addItem(i);
        }
        yearComboBox2.setBounds(595,365,70,20);
        panel.add(yearComboBox2); 

        //Buttons along with required fields for regular
        addRegularButton = new JButton("Add a Regular Student");
        addRegularButton.setBounds(250,400,220,40);
        addRegularButton.setFont(new Font("Fantasy",Font.BOLD,14));
        addRegularButton.setBackground(new Color(25,37,60));//RGB
        addRegularButton.setForeground(Color.WHITE);
        panel.add(addRegularButton);
        addRegularButton.addActionListener(this);

        enrollmentId2 = new JLabel("Enrollment ID:");
        enrollmentId2.setBounds(30,450,100,40);
        enrollmentIdText2 = new JTextField();
        enrollmentIdText2.setBounds(150,450,150,40);
        panel.add(enrollmentId2); 
        panel.add(enrollmentIdText2);

        DaysPresent2 = new JLabel("Days present:");
        DaysPresent2.setBounds(340,450,100,50);
        DaysPresentText2 = new JTextField();
        DaysPresentText2.setBounds(500,450,150,40);
        panel.add(DaysPresent2); 
        panel.add(DaysPresentText2);

        presentPercentageButton = new JButton("Calculate Present Percentage");
        presentPercentageButton.setBounds(250,500,235,30);
        presentPercentageButton.setFont(new Font("Fantasy",Font.BOLD,14));
        presentPercentageButton.setBackground(new Color(25,37,60));
        presentPercentageButton.setForeground(Color.WHITE);
        panel.add(presentPercentageButton);
        presentPercentageButton.addActionListener(this);

        enrollmentId3 = new JLabel("Enrollment ID:");
        enrollmentId3.setBounds(10,540,90,30);
        enrollmentIdText3 = new JTextField();
        enrollmentIdText3.setBounds(120,540,90,30);
        panel.add(enrollmentId3); 
        panel.add(enrollmentIdText3);

        courseName2 = new JLabel("Course Name:");
        courseName2.setBounds(230,540,90,30);
        String[] courses2 = {"Java","Python","C++","C#","Java Script","php"};
        courseNameComboBox2 = new JComboBox<>(courses2);
        courseNameComboBox2.setBounds(330,540,80,30);
        panel.add(courseName2); 
        panel.add(courseNameComboBox2);

        dateOfEnrollment2 = new JLabel("Enrollment Date:");
        dateOfEnrollment2.setBounds(420,540,100,30);
        panel.add(dateOfEnrollment2);
        dayComboBox3= new JComboBox();
        for(int i=1; i<=31; i++)
        {
            dayComboBox3.addItem(i);
        }
        dayComboBox3.setBounds(530,540,40,25);
        panel.add(dayComboBox3);
        String[] months3={"January","February","March","April","May","June","July","August","September","October","November","December"};
        monthComboBox3 =new JComboBox<>(months3);
        monthComboBox3.setBounds(580,540,85,25);
        panel.add(monthComboBox3);
        yearComboBox3 = new JComboBox();
        for(int i=1999; i<=2023; i++)
        {
            yearComboBox3.addItem(i);
        }
        yearComboBox3.setBounds(665,540,70,25);
        panel.add(yearComboBox3);

        grantCertificateButton = new JButton("Grant Certificate");
        grantCertificateButton.setBounds(250,580,220,30);
        grantCertificateButton.setFont(new Font("Fantasy",Font.BOLD,14));
        grantCertificateButton.setBackground(new Color(25,37,60));
        grantCertificateButton.setForeground(Color.WHITE);
        panel.add(grantCertificateButton);
        grantCertificateButton.addActionListener(this);

        displayButton = new JButton("Display");
        displayButton.setBounds(470,615,200,25);
        displayButton.setFont(new Font("Fantasy",Font.BOLD,14));
        displayButton.setBackground(new Color(25,37,60));
        displayButton.setForeground(Color.WHITE);
        panel.add(displayButton);
        displayButton.addActionListener(this);

        clearButton = new JButton("Clear All!");
        clearButton.setBounds(50,615,200,25);
        clearButton.setFont(new Font("Fantasy",Font.BOLD,14));
        clearButton.setBackground(new Color(25,37,60));
        clearButton.setForeground(Color.RED);
        panel.add(clearButton);
        clearButton.addActionListener(this);

        //for Dropout
        panel2 = new JPanel();
        panel2.setSize(750,600);
        panel2.setBackground(new Color(165,170,165));//rgb 
        panel2.setLayout(null);

        Head2= new JLabel("Student Management System");
        Head2.setBounds(250, 30, 300, 100);//x,y width, length.
        Head2.setFont(new Font("SansSerif", Font.BOLD, 20));
        panel2.add(Head2); 

        regularButton = new JButton("<<< Go To Regular");
        regularButton.setBounds(30,50,170,50);
        regularButton.setBackground(new Color(50,115,145));//RGB color setting for regular Button.
        regularButton.setForeground(Color.WHITE);
        regularButton.setFont(new Font("Fantasy",Font.BOLD,13));
        panel2.add(regularButton);
        regularButton.addActionListener(this);

        studentName2= new JLabel("Student Name");
        studentName2.setBounds(30,150,100,40);
        studentNameText2 = new JTextField();
        studentNameText2.setBounds(150,150,150,40);
        panel2.add(studentName2); 
        panel2.add(studentNameText2);

        enrollmentId_DropOut = new JLabel("Enrollment ID");
        enrollmentId_DropOut.setBounds(30,200,100,40);
        enrollmentIdText_DropOut = new JTextField();
        enrollmentIdText_DropOut.setBounds(150,200,150,40);
        panel2.add(enrollmentId_DropOut); 
        panel2.add(enrollmentIdText_DropOut);

        courseName_Dropout = new JLabel("Course Name");
        courseName_Dropout.setBounds(30,250,100,40);
        String[] courses_Dropout = {"Java","Python","C++","C#","Java Script","php"};
        courseNameComboBox_Dropout = new JComboBox<>(courses_Dropout);
        courseNameComboBox_Dropout.setBounds(150,250,150,40);
        panel2.add(courseName_Dropout);
        panel2.add(courseNameComboBox_Dropout);

        courseDuration_Dropout = new JLabel("Course Duration");
        courseDuration_Dropout.setBounds(30,300,100,40);
        courseDurationText_Dropout = new JTextField();
        courseDurationText_Dropout.setBounds(150,300,150,40);
        panel2.add(courseDuration_Dropout); 
        panel2.add(courseDurationText_Dropout);

        tuitionFee_Dropout = new JLabel("Tuition Fee");
        tuitionFee_Dropout.setBounds(30,350,100,40);
        tuitionFeeText_Dropout = new JTextField();
        tuitionFeeText_Dropout.setBounds(150,350,150,40);
        panel2.add(tuitionFee_Dropout); 
        panel2.add(tuitionFeeText_Dropout);

        //half right
        Dob_Dropout = new JLabel("Date Of Birth:");
        Dob_Dropout.setBounds(350,150,100,50);
        panel2.add(Dob_Dropout);
        dayComboBox_Dropout= new JComboBox();
        for(int i=1; i<=31; i++)
        {
            dayComboBox_Dropout.addItem(i);
        }
        dayComboBox_Dropout.setBounds(455,160,40,25);
        panel2.add(dayComboBox_Dropout);

        String[] months_Dropout={"January","February","March","April","May","June","July","August","September","October","November","December"};
        monthComboBox_Dropout =new JComboBox<>(months_Dropout);
        monthComboBox_Dropout.setBounds(500,160,85,25);
        panel2.add(monthComboBox_Dropout);

        yearComboBox_Dropout= new JComboBox();
        for(int i=1999; i<=2023; i++)
        {
            yearComboBox_Dropout.addItem(i);
        }
        yearComboBox_Dropout.setBounds(590,160,80,25);
        panel2.add(yearComboBox_Dropout);

        monthsAttended = new JLabel("Months Attended:");
        monthsAttended.setBounds(350,200,150,50);
        monthsAttendedText =new JTextField();
        monthsAttendedText.setBounds(480,200,150,40);
        panel2.add(monthsAttended);
        panel2.add(monthsAttendedText);

        remainingModules = new JLabel("Remaining Modules:");
        remainingModules.setBounds(350,250,150,50);
        remainingModulesText = new JTextField();
        remainingModulesText.setBounds(480,250,150,40);
        panel2.add(remainingModules);
        panel2.add(remainingModulesText);

        enrollmentDate_Dropout = new JLabel("Enrollment Date:");
        enrollmentDate_Dropout.setBounds(350,300,150,50);
        panel2.add(enrollmentDate_Dropout);
        dayComboBox_Dropout2 = new JComboBox();
        for(int i=1; i<=31; i++)
        {
            dayComboBox_Dropout2.addItem(i);
        }
        dayComboBox_Dropout2.setBounds(460,315,40,25);
        panel2.add(dayComboBox_Dropout2);

        monthComboBox_Dropout2 = new JComboBox();
        String[] months4={"January","February","March","April","May","June","July","August","September","October","November","December"};
        monthComboBox_Dropout2 =new JComboBox<>(months4);
        monthComboBox_Dropout2.setBounds(515,315,90,25);
        panel2.add(monthComboBox_Dropout2);

        yearComboBox_Dropout2= new JComboBox();
        for(int i=1999; i<=2023; i++)
        {
            yearComboBox_Dropout2.addItem(i);
        }
        yearComboBox_Dropout2.setBounds(615,315,60,25);
        panel2.add(yearComboBox_Dropout2);

        dropoutDate = new JLabel("Dropout date:");
        dropoutDate.setBounds(350,350,150,50);
        panel2.add(dropoutDate);
        dayComboBox_Dropout3 = new JComboBox();
        for(int i=1; i<=31; i++)
        {
            dayComboBox_Dropout3.addItem(i);
        }
        dayComboBox_Dropout3.setBounds(460,365,40,25);
        panel2.add(dayComboBox_Dropout3);

        monthComboBox_Dropout3 = new JComboBox();
        String[] months5={"January","February","March","April","May","June","July","August","September","October","November","December"};
        monthComboBox_Dropout3 =new JComboBox<>(months5);
        monthComboBox_Dropout3.setBounds(515,365,90,25);
        panel2.add(monthComboBox_Dropout3);

        yearComboBox_Dropout3= new JComboBox();
        for(int i=1999; i<=2023; i++)
        {
            yearComboBox_Dropout3.addItem(i);
        }
        yearComboBox_Dropout3.setBounds(615,365,60,25);
        panel2.add(yearComboBox_Dropout3);

        addDropoutButton = new JButton("Add Dropout");
        addDropoutButton.setBounds(250,400,220,40);
        addDropoutButton.setFont(new Font("Fantasy",Font.BOLD,14));
        addDropoutButton.setBackground(new Color(44,43,43));
        addDropoutButton.setForeground(Color.WHITE);
        panel2.add(addDropoutButton);
        addDropoutButton.addActionListener(this);

        //Remove
        enrollmentId_DropOut2 = new JLabel("Enrollment ID");
        enrollmentId_DropOut2.setBounds(30,460,100,40);
        enrollmentIdText_DropOut2 = new JTextField();
        enrollmentIdText_DropOut2.setBounds(150,460,150,40);
        panel2.add(enrollmentId_DropOut2); 
        panel2.add(enrollmentIdText_DropOut2);

        //Pay bill
        enrollmentId_DropOut3 = new JLabel("Enrollment ID");
        enrollmentId_DropOut3.setBounds(370,460,100,40);
        enrollmentIdText_DropOut3 = new JTextField();
        enrollmentIdText_DropOut3.setBounds(470,460,150,40);
        panel2.add(enrollmentId_DropOut3); 
        panel2.add(enrollmentIdText_DropOut3);

        removeStudentButton = new JButton("Remove Student");
        removeStudentButton.setFont(new Font("Fantasy",Font.BOLD,14));
        removeStudentButton.setBounds(60,510,200,40);
        removeStudentButton.setBackground(new Color(44,43,43));
        removeStudentButton.setForeground(Color.WHITE);
        panel2.add(removeStudentButton);
        removeStudentButton.addActionListener(this);

        billsPaidButton = new JButton("Bills Pay");
        billsPaidButton.setBounds(450,510,200,40);
        billsPaidButton.setFont(new Font("Fantasy",Font.BOLD,14));
        billsPaidButton.setBackground(new Color(44,43,43));
        billsPaidButton.setForeground(Color.WHITE);
        panel2.add(billsPaidButton);
        billsPaidButton.addActionListener(this);

        clearDropout = new JButton("Clear All!");
        clearDropout.setBounds(30,580,200,30);
        clearDropout.setFont(new Font("Fantasy",Font.BOLD,14));
        clearDropout.setBackground(new Color(44,43,43));
        clearDropout.setForeground(Color.RED);
        panel2.add(clearDropout);
        clearDropout.addActionListener(this);

        displayDropout = new JButton("Display Information");
        displayDropout.setBounds(400,580,200,30);
        displayDropout.setFont(new Font("Fantasy",Font.BOLD,14));
        displayDropout.setBackground(new Color(44,43,43));
        displayDropout.setForeground(Color.WHITE);
        panel2.add(displayDropout);
        displayDropout.addActionListener(this);
        frame.add(panel);//panel of Regular class.
        
        frame.setSize(760,700);
        frame.setVisible(true);
        frame.setResizable(false);
    }
    
    //Inbuilt method for ActionListener
    public void actionPerformed(ActionEvent a)
    {   
        //for changing panels.
        if (a.getSource()== dropoutButton){
            frame.add(panel2);
            panel2.setVisible(true);
            panel.setVisible(false);
        }
        
        if(a.getSource()==regularButton){

            panel2.setVisible(false);
            panel.setVisible(true);

        }

        //for clearing inputs using clear button of Regular class.
        if (a.getSource() == clearButton){
            clearRegularInputs();
        }
        //for clearing inputs using clear button of Dropout  class.
        if(a.getSource() == clearDropout){
            clearDropoutInputs();
        }
        //For Adding a Regular Student.
        if(a.getSource() == addRegularButton){
            addRegular();
        }
        //For Adding a Dropout Student.
        if(a.getSource() == addDropoutButton){
            addDropout();
        }
        //for Calculating Present Percentage.
        if (a.getSource() == presentPercentageButton) {
            presentPercentageCalculation() ;
        }
        //for granting Certificate.
        if (a.getSource() == grantCertificateButton ){
            grantCertificate();
        }
        //For Removing a student
        if (a.getSource() == removeStudentButton){
            removeStudent();
        }
        //For display button of Regular.
        if (a.getSource() == displayButton) {
            displayInformationRegular();
        }
        //For Display button of Dropout.
        if (a.getSource() == displayDropout) {
            displayInformationDropout();
        }
        //For Bills paid button.
        if(a.getSource() == billsPaidButton){
            billsPaid();
        }

    }
    //Method to add a Regular Student.
    private void addRegular(){
        int enrollmentId = Integer.parseInt(enrollmentIdTextField.getText());
        boolean R = false;
        for(Student students : studentList) {
            if(students instanceof Regular && students.getEnrollmentID() == enrollmentId)
            {
                Regular student = (Regular) students;
               
                JOptionPane.showMessageDialog(frame, "Duplicate Id can't be added", "Error", JOptionPane.ERROR_MESSAGE);

                R = true;
            }
        }
        if(R ==false){
            try{
                String studentName = studentNameTextField.getText();
                String courseName = (String)courseNameComboBox.getSelectedItem();
                int courseDuration = Integer.parseInt(courseDurationTextField.getText());
                int tuitionFee = Integer.parseInt(tuitionFeeTextField.getText());

                int DaysPresent = Integer.parseInt(DaysPresentTextField.getText());
                int numberOfModules = Integer.parseInt(numberOfModulesTextField.getText());
                int numberOfCreditHours = Integer.parseInt(numberOfCreditHoursTextField.getText());
                //comboBox of Enrollment date.
                String dateOfEnrollment = dayComboBox.getSelectedItem() + "_" +  monthComboBox.getSelectedItem() + "_" + yearComboBox.getSelectedItem();
                //combobox of DOB.
                String dateOfBirth = dayComboBox2.getSelectedItem() + "_" +  monthComboBox2.getSelectedItem() + "_" + yearComboBox2.getSelectedItem();

                Regular regularStudent = new Regular(dateOfBirth,studentName,courseDuration,tuitionFee,enrollmentId,
                        courseName,dateOfEnrollment,numberOfModules,numberOfCreditHours,DaysPresent);

                studentList.add(regularStudent);
                JOptionPane.showMessageDialog(frame,"Student added to Regular");

            } catch(Exception e){ 

                JOptionPane.showMessageDialog(frame,"Please, enter the correct values", "Error", JOptionPane.ERROR_MESSAGE);

            }
        }

    }

    //Method to add a  dropout student.
    private void addDropout(){
        int enrollmentId_DropOut = Integer.parseInt(enrollmentIdText_DropOut.getText());
        boolean D = false;
        for(Student students : studentList){
            if(students instanceof Dropout && students.getEnrollmentID() == enrollmentId_DropOut){
                if(students instanceof Regular && students.getEnrollmentID() ==enrollmentId_DropOut )
                {
                    Dropout student = (Dropout) students;
                    JOptionPane.showMessageDialog(frame,"Duplicate Id can't be added","Error", JOptionPane.ERROR_MESSAGE);
                    D = true;
                }

            }

        }
        if(D ==false){
            try{
                String studentName2 = studentNameText2.getText();

                String courseName_Dropout = (String) courseNameComboBox_Dropout.getSelectedItem();
                int courseDuration_Dropout = Integer.parseInt(courseDurationText_Dropout.getText());
                int tuitionFee = Integer.parseInt(tuitionFeeText_Dropout.getText());
                //Combobox dob.
                String Dob_Dropout= dayComboBox_Dropout.getSelectedItem()+"_" + monthComboBox_Dropout.getSelectedItem()+"_"+yearComboBox_Dropout.getSelectedItem();
                int monthsAttended = Integer.parseInt(monthsAttendedText.getText());
                int remainingModules = Integer.parseInt(remainingModulesText.getText());
                //ComboBox for Enrollment Date
                String enrollmentDate_Dropout = dayComboBox_Dropout2.getSelectedItem()+"_"+ monthComboBox_Dropout2.getSelectedItem()+ "_"+ yearComboBox_Dropout2.getSelectedItem();
                //ComboBox for Dropout Date.
                String dropoutDate = dayComboBox_Dropout3.getSelectedItem()+"_"+ monthComboBox_Dropout3.getSelectedItem()+"_"+ yearComboBox_Dropout3.getSelectedItem();

                Dropout dropoutStudent = new Dropout(Dob_Dropout,studentName2,courseDuration_Dropout,tuitionFee,enrollmentId_DropOut, 
                        courseName_Dropout,enrollmentDate_Dropout,remainingModules,monthsAttended,dropoutDate);

                studentList.add(dropoutStudent);
                JOptionPane.showMessageDialog(frame,"Student added to Dropout");

            } catch(Exception e){

                JOptionPane.showMessageDialog(frame,"Please, enter the correct values", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    //Method To clear Regular Inputs.
    private void clearRegularInputs(){
        studentNameTextField.setText("");
        enrollmentIdTextField.setText("");
        courseDurationTextField.setText("");
        tuitionFeeTextField.setText("");
        numberOfModulesTextField.setText("");
        numberOfCreditHoursTextField.setText("");
        DaysPresentTextField.setText("");

        courseNameComboBox.setSelectedIndex(0);
        //for dob
        dayComboBox.setSelectedIndex(0);
        monthComboBox.setSelectedIndex(0);
        yearComboBox.setSelectedIndex(0);
        //for enrollment date
        dayComboBox2.setSelectedIndex(0);
        monthComboBox2.setSelectedIndex(0);
        yearComboBox2.setSelectedIndex(0);

        enrollmentIdText2.setText("");
        DaysPresentText2.setText("");
        enrollmentIdText3.setText("");

        courseNameComboBox2.setSelectedIndex(0);
        dayComboBox3.setSelectedIndex(0);
        monthComboBox3.setSelectedIndex(0);
        yearComboBox3.setSelectedIndex(0);
        JOptionPane.showMessageDialog(frame,"All the fields cleared, Thank You!");
    }
    //Method To Clear Dropout Inputs.
    private void clearDropoutInputs(){
        studentNameText2.setText("");
        enrollmentIdText_DropOut.setText("");
        courseDurationText_Dropout.setText("");
        tuitionFeeText_Dropout.setText("");
        monthsAttendedText.setText("");
        remainingModulesText.setText("");
        enrollmentIdText_DropOut2.setText("");
        enrollmentIdText_DropOut3.setText("");

        courseNameComboBox_Dropout.setSelectedIndex(0);
        dayComboBox_Dropout.setSelectedIndex(0);
        monthComboBox_Dropout.setSelectedIndex(0);
        yearComboBox_Dropout.setSelectedIndex(0);

        dayComboBox_Dropout2.setSelectedIndex(0);
        monthComboBox_Dropout2.setSelectedIndex(0);
        yearComboBox_Dropout2.setSelectedIndex(0);

        dayComboBox_Dropout3.setSelectedIndex(0);
        monthComboBox_Dropout3.setSelectedIndex(0);
        yearComboBox_Dropout3.setSelectedIndex(0);
        JOptionPane.showMessageDialog(frame,"All the fields cleared, Thank You!");

    }

    //Method for calculating present Percentage.
    private void presentPercentageCalculation() {
        int enrollmentId2 = Integer.parseInt(enrollmentIdText2.getText());
        int DaysPresent2 = Integer.parseInt(DaysPresentText2.getText());
        for(Student students : studentList) {
            if(students instanceof Regular && students.getEnrollmentID() == enrollmentId2)
            {
                Regular student = (Regular) students;
                JOptionPane.showMessageDialog(frame,"The present percentage of Student is: "+ student.presentPercentage(DaysPresent2) + "%" );
            }
        }

    }
    //Method for granting Certificate
    private void grantCertificate(){
        int enrollmentId3 = Integer.parseInt(enrollmentIdText3.getText()); 
        String courseName2 = (String)courseNameComboBox2.getSelectedItem();
        String dateOfEnrollment2 = dayComboBox3.getSelectedItem() + "_" +  monthComboBox3.getSelectedItem() +"_" + yearComboBox3.getSelectedItem(); 
        for(Student students : studentList) {
            if(students instanceof Regular && students.getEnrollmentID() == enrollmentId3)
            {
                Regular student = (Regular) students;
                boolean isGranted = student.isGrantedScholarship();
                if(isGranted == true){
                    JOptionPane.showMessageDialog(frame, "The student has been graduated and  schlorship granted sucessfully");
                }
                else{
                    JOptionPane.showMessageDialog(frame, "The student has been graduated!,but schlorship is not granted");}
            }
        }
    }
    //Method For calculating bills to be paid.
    private void billsPaid(){
        try{
            int enrollmentId= Integer.parseInt(enrollmentIdText_DropOut3.getText());
            for(Student students : studentList) {
                if(students instanceof Dropout && students.getEnrollmentID() == enrollmentId)
                {
                    Dropout student = (Dropout) students;
                    student.billsPayable();
                    JOptionPane.showMessageDialog(frame,"Bills Paid successfully !");
                }
            }
        }

        catch(Exception e){
            JOptionPane.showMessageDialog(frame,"Error Occured, Please ensure to enter correct enrollmentID. Enter values Correctly", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    //Method to remove a Student
    private void removeStudent(){
        int enrollmentId = Integer.parseInt(enrollmentIdText_DropOut2.getText());
        for(Student students : studentList) {
            if(students instanceof Dropout && students.getEnrollmentID() == enrollmentId)
            {
                Dropout student = (Dropout) students;
                student.removeStudent();
                if(student.getHasPaid()== true){
                    JOptionPane.showMessageDialog(frame,"Student Removed Successfully!");
                }
                else{
                    JOptionPane.showMessageDialog(frame,"Cannot remove student!! Please pay bills!","Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            break;
        }
    }
    //Method for Displaying Information of Regular
    private void displayInformationRegular() {
        System.out.println("\n\n------------------\nRegular Student's Details\n--------------------");
        for (Student students : studentList){
            if(students instanceof Regular){
                students.display();
                System.out.println("\n");

            }
        }

    }
    //Method for Displaying Information of Dropout
    private void displayInformationDropout() {
        System.out.println("\n\n---------------------\nDropout Student's Details\n-----------------------");
        for (Student students : studentList){
            if(students instanceof Dropout){
                students.display();
                System.out.println("\n");

            }

        }
        

    }
    //Main method 
    public static void main(String[]args){
        new StudentGUI();
    }

}
