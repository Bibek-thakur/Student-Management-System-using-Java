/*The Regular class is a sub-class of Student class.
 * It Has four attributes along with inherited attributes from Student Class.
*/
public class Regular extends Student {
    private int numberOfModules;
    private int numberOfCreditHours;
    private int DaysPresent;
    private boolean isGrantedScholarship;
    private double presentPercentage;
    //constructor
    public Regular(String dateOfBirth, String studentName, int courseDuration, int tuitionFee,int enrollmentId,
        String courseName, String dateOfEnrollment, int numberOfModules, int numberOfCreditHours, int DaysPresent)
    {
        // Calling Super class constructor from Student class
        super(dateOfBirth, studentName, courseDuration, tuitionFee);
        //Calling Super class Setter method 
        super.setEnrollmentID(enrollmentId);
        super.setCourseName(courseName);
        super.setDateOfEnrollment(dateOfEnrollment);

        //assigning parameters
        this.numberOfModules = numberOfModules;
        this.numberOfCreditHours = numberOfCreditHours;
        this.DaysPresent = DaysPresent;
        this.isGrantedScholarship = false;
    }

    //Accessor method for each attribute.

    public int getNumOfModules() {
        return numberOfModules;
    }

    public int getNumOfCreditHours() {
        return numberOfCreditHours;
    }

    public int getDaysPresent() {
        return DaysPresent;
    }

    public boolean isGrantedScholarship() {
        return isGrantedScholarship;
    }
    
    public double getPresentPercentage(){
        return this.presentPercentage;
    }

    //Method for present percentage
    public double presentPercentage(int daysPresent) {
        presentPercentage = (daysPresent/(double)getCourseDuration())*100 ;
        char attendanceGrade='E';

        if(presentPercentage>100) {
            System.out.println("Error!Please Re-enter Your Input");
        } 
        else if ( presentPercentage >= 80   ) {
            this.isGrantedScholarship = true;
            attendanceGrade = 'A';
        }
        else if (presentPercentage >=60 ) {
            attendanceGrade = 'B';
        } else if (presentPercentage >= 40) {
            attendanceGrade = 'C';
        } else if (presentPercentage >= 20) {
            attendanceGrade = 'D';
        } else {
            attendanceGrade = 'E';
        }
        return presentPercentage;
    }

    //Method to grant certificate
    public void grantCertificate(String courseName, int enrollmentID, String dateOfEnrollment){
        System.out.println("The student has Graduated successfully.");
        System.out.println("Course: " + courseName);
        System.out.println("Enrollment ID: " + enrollmentID);
        System.out.println("Date of Enrollment: " + dateOfEnrollment);
        if (isGrantedScholarship== true){
            System.out.println("The scholarship has been granted");
        }
        else  {
            System.out.println("Sorry, the scholarship has not been granted.");
        }

    }

    //Method to display details of Regular and Parent class
    public void display() {
        super.display();
        System.out.println("Number of Modules: " + getNumOfModules());
        System.out.println("Number of Credit : " + getNumOfCreditHours());
        System.out.println("Days Present: " + getDaysPresent());
    }

}